from django.shortcuts import render
from django.http import HttpResponse
from django.core.mail import EmailMessage
from django.utils import timezone

import re
import random

from login.models import User
from . import pwHash

# Create your views here.

def login(request):   
    resetSignUpData() #회원가입 관련 데이터 초기화
    
    id = request.POST.get('userID')
    pw = request.POST.get('password')
    idMsg = None
    pwMsg = None

    if id == None:
        return render(request, './login/login.html', { 'id': None, 'pw': None, 'idMsg': None, 'pwMsg': None }) #최초 접속

    if id == "":
        idMsg = "이메일을 입력하세요"
    if pw == "":
        pwMsg = "비밀번호를 입력하세요"

    try:
        user = User.objects.get(email = id)
    except:
        user = None
    
    if user == None:
        idMsg = "사용자가 존재하지 않습니다"
    elif not pwHash.comparePW(pw, user.password):
        pwMsg = "비밀번호가 일치하지 않습니다"
    else:
        print(user.name + " login success")
    

    context = { 'id': id, 'pw': pw, 'idMsg': idMsg, 'pwMsg': pwMsg }
    return render(request, './login/login.html', context) #로그인 실패 시


#회원가입을 위한 데이터
sign_up_form_num = 0
verification_code = "" #이메일 주소 새로 입력시 랜덤 인증코드 생성
email_varified = False #이메일 주소 새로 입력시 False로 초기화, 인증 성공 시 True
user_data = {'id': None, 'pw': None, 'name': None}

def resetSignUpData(): #회원가입 관련 데이터 초기화
    global sign_up_form_num
    global verification_code
    global email_varified
    global user_data

    sign_up_form_num = 0
    verification_code = "" #이메일 주소 새로 입력시 랜덤 인증코드 생성
    email_varified = False #이메일 주소 새로 입력시 False로 초기화, 인증 성공 시 True
    user_data = {'id': None, 'pw': None, 'name': None}

def generateVerificationCode(): #이메일 인증 코드 생성
    code = ""
    for _ in range(6):
        code += str((random.randrange(10)))
    return code

def sendVerificationCode(addr, code): #이메일 인증 코드 송신
    sender_addr = "kdjsgk3910@naver.com"

    title = "인증코드"
    message = "인증 코드 " + code + "를 입력하세요"

    #email = EmailMessage(title, message, sender_addr, to=[addr], )
    #email.send()
    print(message) #일단 콘솔에 인증코드 출력 (이메일 전송 기능 나중에 구현)

def signUp(request):
    #global sign_up_form_num
    #data = { 'f0': ['userID'], 'f1': ['verification'], 'f2': ['password', 'passwordConfirm'], 'f3': ['userName'] }  
    #data = [['userID'], ['verification'], ['password', 'passwordConfirm'], ['userName']]

    if sign_up_form_num == 0:
        context = signUpForm0(request)
    elif sign_up_form_num == 1:
        context = signUpForm1(request)
    elif sign_up_form_num == 2:
        context = signUpForm2(request)
    elif sign_up_form_num == 3:
        context = signUpForm3(request)

    return render(request, './login/sign_up.html', context)

def signUpForm0(request):
    resetSignUpData()
    global sign_up_form_num
    global verification_code
    global user_data

    emailRegex = '^[a-zA-Z0-9+-_.]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$' #이메일 형식 체크를 위한 regex

    id = request.POST.get('userID')
    if id == None: id = "none"
    message = "none"

    if id == "none" or id == "":
        message = "이메일을 입력하세요"
    elif not re.search(emailRegex, id):
        message = "이메일 형식이 올바르지 않습니다"
    elif User.objects.filter(email = id).exists(): #중복되는 아이디 존재
        message = "중복되는 이메일이 이미 존재합니다"
    else: #이메일이 유효할 경우
        user_data['id'] = id
        verification_code = generateVerificationCode() #인증 코드 생성
        sendVerificationCode(id, verification_code) #인증 코드 전송

        sign_up_form_num += 1 #폼 변경
        id = "none" #input으로 ["none"] 전달

    context = { 'form_num': sign_up_form_num, 'input': [id], 'messages' : [message] }
    #return render(request, './login/sign_up.html', context)
    return context

def signUpForm1(request):
    global sign_up_form_num
    global verification_code
    global email_varified

    code_ans = request.POST.get('verification')
    if code_ans == None: code_ans = "none"
    message = "none"

    if code_ans == "none" or code_ans == "":
        message = "인증 코드를 입력하세요"
    elif code_ans != verification_code:
        message = "코드가 일치하지 않습니다"
    else:
        email_varified = True
        sign_up_form_num += 1 #폼 변경
        code_ans = "none"

    context = { 'form_num': sign_up_form_num, 'input': [code_ans], 'messages' : [message] }
    return context

def signUpForm2(request):
    global sign_up_form_num
    global user_data

    pw = request.POST.get('password')
    if pw == None: pw = "none"
    pw_confirm = request.POST.get('passwordConfirm')
    if pw_confirm == None: pw_confirm = "none"

    pwMsg = "none"
    pwConfirmMsg = "none"

    isValidPw = False
    isValidPwConfirm = False

    if pw == "none" or pw == "":
        pwMsg = "비밀번호를 입력하세요"
    else:
        isValidPw = True

    if pw_confirm == "none" or pw_confirm == "":
        pwConfirmMsg = "비밀번호를 재입력하세요"
    elif pw_confirm != pw:
        pwConfirmMsg = "비밀번호가 일치하지 않습니다"
    else:
        isValidPwConfirm = True

    if isValidPw and isValidPwConfirm:
        user_data['pw'] = pw
        sign_up_form_num += 1 #폼 변경
        pw = "none"
        pw_confirm = "none"

    context = { 'form_num': sign_up_form_num, 'input': [pw, pw_confirm], 'messages' : [pwMsg, pwConfirmMsg] }
    return context

def signUpForm3(request):
    global sign_up_form_num
    global user_data

    name = request.POST.get('userName')
    if name == None: name = "none"

    nameMsg = "none"

    if name == "none" or name == "":
        nameMsg = "사용자 이름을 입력하세요"
    else:
        user_data['name'] = name
        register() #회원 정보 등록
        sign_up_form_num += 1 #폼 변경
        name = "none"

    context = { 'form_num': sign_up_form_num, 'input': [name], 'messages' : [nameMsg] }
    return context

def register(): #회원 데이터 db에 추가
    global email_varified
    global user_data

    if not email_varified:
        print("email does not varified")
        return False
    
    if user_data['id'] == None or user_data['pw'] == None or user_data['name'] == None:
        print("user data error")
        return False
    
    if User.objects.filter(email = user_data['id']).exists(): #중복되는 아이디 존재
        print("not unique id")
        return False
  
    new_user = User(email = user_data['id'], password = pwHash.generateHashedPW(user_data['pw']), name = user_data['name'])
    new_user.save()
    print("register success")
    return True
